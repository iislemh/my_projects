<?php

    function del_student($user_login, $null){
        if ($null != null)
        {
            echo ("\nWrong format for the function!\n");
            return(0);
        }
        $count = check_if_exist($user_login);
        if ($count == 0)
            echo("\nNo user found, nothing has been changed.\n");
        else 
        {
            echo("\nAre you sure ?");
            prompt();
            $del = readline();
            while (($del != "yes") && ($del != "no")) {
                echo("Wrong answer, type yes or no");
                prompt();
                $del = readline();
            }
            if ($del == "yes") {
                echo("User deleted !\n");
                del_user_db($user_login);
            }
            else if ($del == "no")
                echo("User conserved.\n");
            return(0);
        }
    }
    function add_student($var, $null) {
        
	    if (preg_match('#[a-z]{1,6}_[a-z0-9]{1}$#', $var) && ($null == null)) 
		{
		    $exist = check_if_exist($var);
			
			if ($exist == 1)
			{
			   echo("\nStudent login is already used !\nNothing was added.\n");
			   return(0);
			}
			$login = $var;
			$name = name_user();
			$age = age_user();
			$email = email_user();
			$phone_number = phone_number();
			if ($exist == 0) {
    			add_user_db($login, $name, $age, $email, $phone_number);
			    echo("\nUser registered !\n");
			}
		}
	    else
		    echo ("\nWrong format for the function!\n");
    }
    
    function movies_storing()
{  ini_set('auto_detect_line_endings',TRUE);
        $c = new MongoClient();
        $db = $c->db_etna;
        $collection = $db->createCollection('movies');
        $row = 0;
        if (($handle = fopen("movies.csv", "r")) !== FALSE) {
            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                $num = count($data);
                $f = array(
                    "imdb_code" => "".$data[1]."",
                    "title" => "".$data[5]."",
                    "year" => "".intval($data[11])."",
                    "genres" => explode(", ", $data[12]),
                    "directors"=> explode(", ", $data[7]),
                    "rate" => "".floatval($data[9])."",
                    "link" => "".$data[15]."",
                    "stock" => rand( 0, 5 ),
                    "renting_students" => ""
                );
                $db->movies->insert($f);
                $row++;
                $collection->update(array("imdb_code" => "".$data[1].""), 
                array('$set' => array("renting_students" => "")));
            }
        }
        echo("\n".$row." movies successfully stored !\n");
        fclose($handle);
        return(0);
    }
    
    function ckeck_login($arv3)
    {
        $c = new MongoClient();
        $db = $c->db_etna;
        $collection = $db->createCollection('students');
        $check = $collection->find(array("login" => "".$arv3.""))->count();
        if ($check == 0)
        {
            echo "There is no such user in our database !\n";
            return(1);
        }
        else
            return(0);
        $c->close();
    }
?>