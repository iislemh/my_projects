<?php

    function name_user()
    {
            echo("\nName ?");
            prompt();
            $name = readline();
            while (!preg_match('#^[a-zA-Z][a-z]+$#', $name))
                {
                    echo "Incorrect name\n";
                    echo("Name ?");
                    prompt();
                    $name = readline();
                }
            return($name);    
    }
    
    function age_user()
    {
            echo("Age ?");
            prompt();
            $age = readline();
            while ($age < 1 || $age > 99)
                {
                    echo "Members must be from 1 to 99 years old \n";
                    echo("Age ?");
                    prompt();
                    $age = readline();
                }
            return($age);         
    }        
    
    function email_user()
    {
        echo("Email ?");
        prompt();
        $email = readline();
        while (!preg_match('#^[a-zA-Z -_.]+@[a-zA-Z-_]+.[a-z]{1,4}$#',$email))
        {
            echo "Incorrect e-mail type\n";
            echo("Email ?");
            prompt();
            $email = readline();
        }
        return($email);     
    }
    
    function phone_number()
    {
        echo("Phone number ?");
        prompt();
        $phone_number = readline();
        while (!preg_match('#^0[1-68]([ .-]?[0-9]{2}){4}#', $phone_number))
        {
            echo "Incorrect tel number, (10 numbers)\n";
            echo("Phone number ?");
            prompt();
            $phone_number = readline();
        }
        return($phone_number);     
    }
?>              
       
      