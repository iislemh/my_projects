
Hi there, We proudly present you our etna_movies script.

To get you started, try to input the name of the file with a previous ./
ex : (./*etna_movies add_student legal_q)

1) List of all user functions ;

    - add_student ,as the name suggest it will add a new student to the database
                   with the login that you have added just after the name of the
                   function, next steps will be guided ..

    - del_student ,will delete the student with the following login
                   (will ask confirmation though.)

    - update_student ,will ask you wich element from the student you wis to
                      update, login won't be able to be modified.
    
    - show_student : *With nothing behind, will show you the list of all of the 
                      students in our database
                     *With a login behind will show you the informations of the
                      specified student.

2) List of all movies functions ;

    - movies_storing ,it will create a mongo database from a file named 
                      "movies.csv"  

    ##show_movies## will show you the list of movies prensent in our database
                    depending of wich parameter you add :
                   
    - show_movies ,will show you the list of all of the movies stored in our 
                   database ordered alphabetically.
    
    - show_movies desc ,same thing that the one above but reverse alphabetically 
    
    - show_movies #categorie# ,replace #categorie# by one of the movies then the     
                               element wanted.
                              
                              EX: show_movies genres action
                              Will show all actions movies.
                              
                              EX: show_movies year 1995
                              Will show movies made in 1995.
    
3) List of the renting functions ;

    - rent_movie ,followed by the login of the user who wish to rent a movie.

    - return_movie ,followed by the login of the user who wish to return a movie
    
    - show_rented_movies ,....  show the rented movies.

4) Credits go to ammani_m and legal_q;


## Support & Contact

you can contact us at legal_q@etna-alternance.net

Enjoy your product !