<?php
    function create_database_and_coll()
    {
        $c = new MongoClient();
        $db = $c->db_etna;
        $db->createCollection('students');
    }    
    function check_if_exist($login)
    {
        $c = new MongoClient();
        $db = $c->db_etna;
        $num = $db->students->count(array('login'=> $login));
        if ($num > 0)
            return(1);
        else
            return(0);
    }
    
    function add_user_db($login, $name, $age, $email, $phone_number)
    {
    	$c = new MongoClient();
    	$db = $c->db_etna;
    	$collection = $db->createCollection('students');
    	$doc = array(
    		"login" => "".$login."",
    		"name" => "".$name."",
    		"age" => "".$age."",
    		"email" => "".$email."",
    		"num" => "".$phone_number."",
    		"rented_movies" => array()
    		);
    	$db->students->insert($doc);
    	$collection->update(array("login" => "".$login.""), 
    	array('$set' => array("rented_movies" => "")));
    	$c->close();
    }
    
    function del_user_db($user_login)
    {
        $c = new MongoClient();
        $db = $c->db_etna;
		$db->students->remove(array("login" => $user_login));
    }
    
    function update_student_db($login, $modif, $new)
    {
	    $c = new MongoClient();
    	$db = $c->db_etna;
    	$collection = $db->createCollection('students');
    	$collection->update(array("login" => "".$login.""), 
    	array('$set' => array("".$modif."" => "".$new."")));
    	echo "User informations modified !\n";
    	$c->close();
    }
?>