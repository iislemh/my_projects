#!/usr/bin/php
<?php
    require_once('add_user.php');
    require_once('main_functions.php');
    require_once('functions.php');
    require_once('database_interaction.php');
    require_once('functions_show_update.php');
    require_once('show_movies.php');
    require_once('rent_movie.php');
    
    function start($nbr_arg, $func_name, $usr_login, $third_param) {
        $check = check_arg($nbr_arg, $usr_login, $func_name);    
        if ($check == 1)
            return(0);
        create_database_and_coll();
        launch_func($func_name, $usr_login, $third_param, $fourth_param);   
    }
    start($argc,$argv[1],$argv[2], $argv[3], $argv[4]);
    echo("\n");
?>