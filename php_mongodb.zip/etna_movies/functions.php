<?php
    function prompt() {
        echo("\n> ");
    }
    function check_arg($argn, $login, $func_name) {
        if (($argn > 4))
            echo("\n-You didn't input a valid number of arguments.\n");
        if ($argn < 5){
            if (($func_name == "show_student") && ($argn == 2))
            {
                show_student_alone();
                return(1);
            }
        }
        if (($argn == 3) && ($func_name != "show_movies"))
        {
            if (preg_match('#^[a-zA-Z]{1,6}_[a-zA-Z0-9]$#', $login))
                return(0);
            if (!preg_match('#^[a-zA-Z]{1,6}_[a-zA-Z0-9]$#', $login)) {
                echo ("The login type is not correct.\n");
                return(1);
            }
        }
    }
    
    function launch_func($func_name, $second_param, $third_param) {
        
        if (!function_exists($func_name))
            {
                echo"function does not exist\n";
                return(0);
            }
        else
            $func_name($second_param, $third_param, $fourth_param);
    }
?>