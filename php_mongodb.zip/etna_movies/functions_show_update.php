<?php

function update_student($login, $null)
{ 
	$c = new MongoClient();
	$db = $c->db_etna;
	$check = $db->students->find(array("login" => "".$login.""))->count();
	if (($check != 1) ||  ($null != null))
	{
		echo "\nThere is no students with such login\n";
		return(0);
	}	
	$c->close();
	echo "What do you want to update?\n";
	prompt();
	$modif = readline();
	while (($modif == "login") || (($modif != "name") && ($modif != "age") 
	&& ($modif != "phone") && ($modif != "email")))
	{
		echo "You can't modify that\n";
		echo "What do you want to update?\n";
		prompt();
		$modif = readline();
	}
	echo 'New '.$modif.' ?';
	prompt();
	$new = readline();
	update_student_db($login, $modif, $new);
}

function show_student($login) 
    {
    	$c = new MongoClient();
		$db = $c->db_etna;
		$collection = $db->createCollection('students');
        $f = $collection->find(array("login" => "".$login.""));
        foreach($f as $k)
        {
        	echo "\n";
	        echo 'login 		: '.$k['login'].''."\n";
	    	echo 'name  		: '.$k['name'].''."\n";
	    	echo 'age   		: '.$k['age'].''."\n";
	    	echo 'email 		: '.$k['email'].''."\n";
	    	echo 'phone 		: '.$k['num'].''."\n";
	    	echo 'rented_movies 	: '.$k['rented_movies'].''."\n";
        }
        $c->close();	
    }

	function  show_student_alone()
	{
			$c = new MongoClient();
			$db = $c->db_etna;
			$num = $db->createCollection('students')->count();
			$collection = $db->createCollection('students');
	        $f = $collection->find();
	        foreach($f as $k)
	        {
	            echo "\n";
	            echo $k['login'].' '.$k['name']. ' '.$k['age']. ' '.$k['email'].
	        	' '.$k['num']. ''."\n";
	        }
	        echo "\n";
	        if ($num > 1)
	    		echo 'There are '.$num.' students in our database'."\n";
	    	else
	    		echo 'There is '.$num.' student in our database'."\n";
	        $c->close();
	}  
?>