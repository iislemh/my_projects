<?php

    function verif_rent($arv2, $arv3)
    {
        $count = 0;
        if (!preg_match('#^tt[0-9]{7}$#', $arv2))
        {
            echo "The ID's type is not correct\n";
            return(0);
        }
        $c = new MongoClient();
        $db = $c->db_etna;
        $collection = $db->createCollection('movies');
        $f = $collection->find(array("imdb_code" => "".$arv2.""));
        foreach($f as $k)
        {
            if ($k["stock"] == 0)
                $count++;
        }
        if ($count == 1)
        {
            echo "Stock-out !\n";
            return(0);
        }
        if ($count == 0)
        {
            return(1);
        } 
    }
    
    function verif_rent2($arv2)
    {
       if (!preg_match('#^tt[0-9]{7}$#', $arv2))
        {
            echo "The ID's type is not correct\n";
            return(0);
        }
        $c = new MongoClient();
        $db = $c->db_etna;
        $collection = $db->createCollection('movies');
        $f = $collection->find(array("imdb_code" => "".$arv2.""))->count();
        if ($f == 0)
            echo "There is no such movie in our database";
        else
            return(1);
        $c->close();    
            
    }

    function update_movies_db($id, $login)
    {
	    $c = new MongoClient();
    	$db = $c->db_etna;
    	$collection = $db->createCollection('movies');
    	$collection_user = $db->createCollection('students');
    	$Query = array("imdb_code" => $id);
        $cursor = $collection->find($Query);
        foreach ($cursor as $doc) 
            $name = $doc["renting_students"]."-".$login ;
        $Query2 = array("login" => $login);
        $cursor2 = $collection_user->find($Query2);
        foreach ($cursor2 as $docu) 
            $name2 = $docu["rented_movies"]."-".$doc["title"];
    	$collection->update(array("imdb_code" => "".$id.""), 
    	array('$inc' => array("stock" => -1)));
    	$collection->update(array("imdb_code" => "".$id.""), 
    	array('$set' => array("renting_students" => $name)));
    	$collection_user->update(array("login" => "".$login.""), 
    	array('$set' => array("rented_movies" => $name2)));
    	echo "Rented !\n";
    	$c->close();
    }
    
    function return_movie($arv2, $arv3)
    {
        $i = ckeck_login($arv3);
        if ($i == 0) 
            $j = verif_rent2($arv2);
        if ($j == 1)
            return_movie_db($arv2, $arv3);
    }
    
    function return_movie_db($id, $login)
    {
        $c = new MongoClient();
    	$db = $c->db_etna;
    	$collection = $db->createCollection('movies');
    	$collection_user = $db->createCollection('students');
    	$Query = array("imdb_code" => $id);
        $cursor = $collection->find($Query);
        foreach ($cursor as $doc)
            $name = preg_replace("/-$login/", '', $doc["renting_students"], 1);
        $Query2 = array("login" => $login);
        $cursor2 = $collection_user->find($Query2);
        $vari = $doc['title'];
        foreach ($cursor2 as $docu) 
            $che_ck = $docu["rented_movies"];
            $name2 = preg_replace("/-$vari/", '', $docu["rented_movies"], 1);
        if ($che_ck != $name2)
        {
        	$collection->update(array("imdb_code" => "".$id.""),
        	array('$inc' => array("stock" => 1)));
        	$collection->update(array("imdb_code" => "".$id.""), 
        	array('$set' => array("renting_students" => $name)));
        	$collection_user->update(array("login" => "".$login.""), 
        	array('$set' => array("rented_movies" => $name2)));
        	echo "Returned\n";
        }
        if ($che_ck == $name2)
            echo "\nThis movie is not actually rented by that student !\n";
        $c->close();
    }
?>        