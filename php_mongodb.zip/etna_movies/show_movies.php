<?php
    function show_movies($type, $param) {
        $num = 0;
        $c = new MongoClient();
        $db = $c->db_etna;
        if (is_null($type) && is_null($param))
        {
            show_movies_alphab();
            $num++;
        }
        if (($type == "desc") && is_null($param))
        {
            show_movies_rev_alphab();
            $num++;
        }
        else if ($num == 0)
        {
            $collection = $db->createCollection('movies');
    	    if ($type == "rate")
                $z = $collection->find(array("rate" => 
                new MongoRegex("/$param.?.*/")));
            else
        	    $z = $collection->find(array($type => $param));
            foreach($z as $k)
            {
                echo "\n"."imdb_code : ".$k['imdb_code']." | Movie's name : "
                .$k['title'];
    	        $num++;
            }
            echo "\n*".$num."*";
            if ($num == 0)
                echo"\nNothing here\n";
        }
        $c->close();
    }


    function show_movies_alphab() 
    {
        $c = new MongoClient();
		$db = $c->db_etna;
		$collection = $db->createCollection('movies');
        $f = $collection->find();
        $f= $f->sort(array('title' => 1));
        foreach($f as $k)
        {
            echo "\n"."imdb_code : ".$k['imdb_code']." | Movie's name : "
            .$k['title'];
            $count++;
        }
        echo "\n*".$count."*";
        $c->close();
    }
    function show_movies_rev_alphab()   {
        $c = new MongoClient();
		$db = $c->db_etna;
		$collection = $db->createCollection('movies');
        $f = $collection->find();
        $f= $f->sort(array('title' => -1));
        foreach($f as $k)
        {
          echo "\n"."imdb_code : ".$k['imdb_code']." | Movie's name : "
          .$k['title'];
          $count++;
        }
        echo "\n*".$count."*";
        $c->close();
    }
    function show_rented_movies()
    {
        $c = new MongoClient();
		$db = $c->db_etna;
		$collection = $db->createCollection('movies');
        $f = $collection->find(array("renting_students" => 
        new MongoRegex("/.+/")));
        foreach($f as $k)
        {
          echo "\n"."imdb_code : ".$k['imdb_code']." | Movie's name : "
          .$k['title'];
          $count++;
        }
        echo "\n*".$count."*";
        $c->close();
    }
    
    function rent_movie($arv2, $arv3)
    {
        $i = ckeck_login($arv3);
        if ($i == 0) 
            $j = verif_rent($arv2, $arv3);
        if ($j == 1)
            update_movies_db($arv2, $arv3);
    }
?>