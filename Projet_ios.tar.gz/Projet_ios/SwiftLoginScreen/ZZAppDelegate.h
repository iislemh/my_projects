//
//  ZZAppDelegate.h
//  JolicutREGLOG
//
//  Created by Guillaume FORESTIER on 21/04/16.
//  Copyright © 2016 Forestier Guillaume. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZZAppDelegate : UIResponder <UIApplicationDelegate>

@property(strong, nonatomic) UIWindow *window;

@end
